### Hexlet tests and linter status:
[![Actions Status](https://github.com/skullikk/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/skullikk/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/b74a577bc9ecb959a3ca/maintainability)](https://codeclimate.com/github/skullikk/python-project-49/maintainability)


[How to play](https://asciinema.org/a/eVzT84KluUeilQ6Jq750Xj2js)