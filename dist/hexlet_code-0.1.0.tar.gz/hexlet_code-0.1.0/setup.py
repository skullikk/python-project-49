# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/skullikk/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/skullikk/python-project-49/actions)\n\n[![Maintainability](https://api.codeclimate.com/v1/badges/b74a577bc9ecb959a3ca/maintainability)](https://codeclimate.com/github/skullikk/python-project-49/maintainability)\n\n\n[How to play](https://asciinema.org/a/eVzT84KluUeilQ6Jq750Xj2js)',
    'author': 'Andrey Cherepanov',
    'author_email': 'skullikk@mail.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
